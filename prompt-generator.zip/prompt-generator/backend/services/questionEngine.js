const { GoogleGenAI } = require('@google/genai');

const ai = new GoogleGenAI({ apiKey: process.env.AI_API_KEY || '' });
const MODEL = process.env.AI_MODEL || 'gemini-2.5-flash';

async function getNextQuestion(session) {
  const maxQuestions = parseInt(process.env.MAX_QUESTIONS_PER_SESSION, 10) || 4;
  if (session.questionCount >= maxQuestions) {
    return { hasMoreQuestions: false, question: null };
  }

  const systemInstruction = `You are a dynamic questioning engine. Given the project context and prior QA history, determine the single most valuable next question.
If enough information exists, set hasMoreQuestions to false and question to null.
Respond with JSON matching:
{
  "hasMoreQuestions": boolean,
  "question": null | {
    "id": string,
    "type": "single_choice" | "multiple_choice" | "text" | "number",
    "text": string,
    "helpText": string,
    "options": string[],
    "required": boolean
  }
}`;

  const context = {
    originalIdea: session.originalIdea,
    taskType: session.taskType,
    requirements: session.requirements,
    qaHistory: session.qaHistory
  };

  const response = await ai.models.generateContent({
    model: MODEL,
    contents: JSON.stringify(context),
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      temperature: 0.2
    }
  });

  const parsed = JSON.parse(response.text.trim());
  return {
    hasMoreQuestions: Boolean(parsed.hasMoreQuestions && parsed.question),
    question: parsed.question || null
  };
}

module.exports = { getNextQuestion };