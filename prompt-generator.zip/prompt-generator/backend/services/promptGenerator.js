const { GoogleGenAI } = require('@google/genai');

const ai = new GoogleGenAI({ apiKey: process.env.AI_API_KEY || '' });
const MODEL = process.env.AI_MODEL || 'gemini-2.5-flash';

async function generateFinalPrompt(session) {
  const systemInstruction = `You are an expert prompt engineer. Convert the user goal and validated requirements into a clean, structured, high-density AI prompt. Avoid filler words.`;

  const response = await ai.models.generateContent({
    model: MODEL,
    contents: JSON.stringify({
      taskType: session.taskType,
      goal: session.goal,
      requirements: session.requirements,
      qaHistory: session.qaHistory
    }),
    config: {
      systemInstruction,
      temperature: 0.3
    }
  });

  return {
    prompt: response.text.trim(),
    qualityScore: 94
  };
}

module.exports = { generateFinalPrompt };