const { GoogleGenAI } = require('@google/genai');

const ai = new GoogleGenAI({ apiKey: process.env.AI_API_KEY || '' });
const MODEL = process.env.AI_MODEL || 'gemini-2.5-flash';

async function validateRequirements(session) {
  const systemInstruction = `Check requirements for technical contradictions or severe ambiguity.
Respond with JSON matching:
{
  "isValid": boolean,
  "reason": string,
  "conflictQuestion": null | {
    "id": string,
    "type": "single_choice" | "text",
    "text": string,
    "options": string[],
    "required": true
  }
}`;

  const response = await ai.models.generateContent({
    model: MODEL,
    contents: JSON.stringify({
      goal: session.goal,
      requirements: session.requirements,
      qaHistory: session.qaHistory
    }),
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      temperature: 0.1
    }
  });

  return JSON.parse(response.text.trim());
}

module.exports = { validateRequirements };