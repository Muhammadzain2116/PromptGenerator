const requestCounts = new Map();

/**
 * Configurable IP Rate Limiter Middleware
 */
function rateLimiter(options = {}) {
  const windowMs = options.windowMs || parseInt(process.env.RATE_LIMIT_WINDOW_MS, 10) || 15 * 60 * 1000;
  const max = options.max || parseInt(process.env.RATE_LIMIT_MAX_REQUESTS, 10) || 60;

  // Periodic cleanup
  setInterval(() => {
    const now = Date.now();
    for (const [ip, data] of requestCounts.entries()) {
      if (now - data.startTime > windowMs) {
        requestCounts.delete(ip);
      }
    }
  }, windowMs);

  return (req, res, next) => {
    const clientIp = req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
    const now = Date.now();

    let clientData = requestCounts.get(clientIp);

    if (!clientData || (now - clientData.startTime > windowMs)) {
      clientData = { count: 1, startTime: now };
      requestCounts.set(clientIp, clientData);
      return next();
    }

    clientData.count++;

    if (clientData.count > max) {
      return res.status(429).json({
        error: {
          code: 'RATE_LIMIT_EXCEEDED',
          message: 'Too many requests. Please wait a few moments before trying again.'
        }
      });
    }

    next();
  };
}

module.exports = rateLimiter;