const { GoogleGenAI } = require('@google/genai');

const ai = new GoogleGenAI({ apiKey: process.env.AI_API_KEY || '' });
const MODEL = process.env.AI_MODEL || 'gemini-2.5-flash';

async function analyzeIdea(idea) {
  const systemInstruction = `You are a requirements analyst. Classify the task and determine if clarifying questions are needed.
Respond with JSON matching:
{
  "taskType": string,
  "goal": string,
  "complexity": "simple" | "medium" | "complex",
  "knownRequirements": { [key: string]: string },
  "missingCriticalInformation": string[],
  "needsQuestions": boolean
}`;

  const response = await ai.models.generateContent({
    model: MODEL,
    contents: `User Idea: "${idea}"`,
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      temperature: 0.2
    }
  });

  return JSON.parse(response.text.trim());
}

module.exports = { analyzeIdea };