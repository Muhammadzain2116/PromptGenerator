﻿require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const crypto = require('crypto');
const { GoogleGenAI } = require('@google/genai');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(cors());

// AI Client
const ai = new GoogleGenAI({ apiKey: process.env.AI_API_KEY || '' });
const MODEL = process.env.AI_MODEL || 'gemini-2.5-flash';
const sessions = new Map();

// 1. Start / Analyze
app.post('/api/prompt/start', async (req, res) => {
  try {
    const { idea } = req.body;
    if (!idea || !idea.trim()) {
      return res.status(400).json({ error: { message: 'Idea is required' } });
    }

    const sessionId = crypto.randomUUID();
    const response = await ai.models.generateContent({
      model: MODEL,
      contents: `Analyze this user request: "${idea}".
      Determine the taskType and if 1 clarifying question is needed.
      Return strictly JSON:
      {"taskType": "string", "needsQuestion": boolean, "question": {"id": "q1", "type": "single_choice", "text": "Question text?", "options": ["Option A", "Option B", "Let AI decide"]}}`,
      config: { responseMimeType: 'application/json' }
    });

    const data = JSON.parse(response.text.trim());
    const session = {
      sessionId,
      idea: idea.trim(),
      taskType: data.taskType || 'General',
      requirements: {},
      count: 0
    };
    sessions.set(sessionId, session);

    if (!data.needsQuestion || !data.question) {
      return res.json({ sessionId, status: 'ready', taskType: session.taskType, summary: { Goal: idea } });
    }

    session.count = 1;
    return res.json({ sessionId, status: 'question', taskType: session.taskType, question: data.question });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// 2. Answer
app.post('/api/prompt/answer', async (req, res) => {
  try {
    const { sessionId, questionId, answer } = req.body;
    const session = sessions.get(sessionId);
    if (!session) return res.status(404).json({ error: { message: 'Session not found' } });

    session.requirements[questionId] = Array.isArray(answer) ? answer.join(', ') : answer;

    if (session.count >= 3) {
      return res.json({ status: 'ready', summary: session.requirements });
    }

    const response = await ai.models.generateContent({
      model: MODEL,
      contents: `Goal: "${session.idea}", Answers so far: ${JSON.stringify(session.requirements)}.
      Decide if 1 more question is necessary.
      Return strictly JSON:
      {"hasMore": boolean, "question": {"id": "q${session.count + 1}", "type": "single_choice", "text": "Question?", "options": ["Opt A", "Opt B", "Let AI decide"]}}`,
      config: { responseMimeType: 'application/json' }
    });

    const data = JSON.parse(response.text.trim());
    if (!data.hasMore || !data.question) {
      return res.json({ status: 'ready', summary: session.requirements });
    }

    session.count++;
    return res.json({ status: 'question', question: data.question });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// 3. Generate
app.post('/api/prompt/generate', async (req, res) => {
  try {
    const { sessionId } = req.body;
    const session = sessions.get(sessionId);
    if (!session) return res.status(404).json({ error: { message: 'Session not found' } });

    const response = await ai.models.generateContent({
      model: MODEL,
      contents: `Create an expert, structured AI prompt for:
      Goal: ${session.idea}
      Specifications: ${JSON.stringify(session.requirements)}`
    });

    return res.json({
      status: 'complete',
      taskType: session.taskType,
      prompt: response.text.trim(),
      qualityScore: 95
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// Serve frontend
app.use(express.static(path.join(__dirname, 'frontend')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend/index.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 App running at http://localhost:${PORT}`);
});
