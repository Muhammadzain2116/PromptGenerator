/**
 * ui.js
 * DOM rendering, element queries, and view transition engine.
 */

const UI = {
  elements: {
    // Screens
    screenHome: document.getElementById('screen-home'),
    screenAnalyzing: document.getElementById('screen-analyzing'),
    screenQuestion: document.getElementById('screen-question'),
    screenReview: document.getElementById('screen-review'),
    screenResult: document.getElementById('screen-result'),
    screenError: document.getElementById('screen-error'),

    // Home
    ideaForm: document.getElementById('idea-form'),
    ideaInput: document.getElementById('idea-input'),
    ideaCharCount: document.getElementById('idea-char-count'),
    ideaError: document.getElementById('idea-error'),
    exampleChips: document.querySelectorAll('.example-chip'),
    brandLogo: document.getElementById('brand-logo'),

    // Analyzing
    analyzingTitle: document.getElementById('analyzing-title'),
    analyzingStep: document.getElementById('analyzing-step'),
    analyzingBar: document.getElementById('analyzing-bar'),

    // Question
    questionForm: document.getElementById('question-form'),
    questionMeta: document.getElementById('question-meta'),
    questionText: document.getElementById('question-text'),
    questionHelp: document.getElementById('question-help'),
    answerControls: document.getElementById('answer-controls'),
    questionError: document.getElementById('question-error'),
    btnQuestionBack: document.getElementById('btn-question-back'),
    btnQuestionSkip: document.getElementById('btn-question-skip'),
    btnQuestionContinue: document.getElementById('btn-question-continue'),

    // Review
    reviewOriginalIdea: document.getElementById('review-original-idea'),
    reviewAnswersList: document.getElementById('review-answers-list'),
    btnReviewBack: document.getElementById('btn-review-back'),
    btnReviewConfirm: document.getElementById('btn-review-confirm'),

    // Result
    promptOutput: document.getElementById('prompt-output'),
    promptTag: document.getElementById('prompt-tag'),
    promptWordCount: document.getElementById('prompt-word-count'),
    qualityScoreValue: document.getElementById('quality-score-value'),
    btnCopyPrompt: document.getElementById('btn-copy-prompt'),
    copyBtnLabel: document.getElementById('copy-btn-label'),
    btnResultEdit: document.getElementById('btn-result-edit'),
    btnResultRegenerate: document.getElementById('btn-result-regenerate'),
    btnResultRestart: document.getElementById('btn-result-restart'),

    // Error
    errorTitle: document.getElementById('error-title'),
    errorMsg: document.getElementById('error-msg'),
    btnErrorRetry: document.getElementById('btn-error-retry'),
    btnErrorHome: document.getElementById('btn-error-home')
  },

  /**
   * Switch the visible screen container cleanly
   */
  showScreen(screenName) {
    const screens = [
      this.elements.screenHome,
      this.elements.screenAnalyzing,
      this.elements.screenQuestion,
      this.elements.screenReview,
      this.elements.screenResult,
      this.elements.screenError
    ];

    screens.forEach((screen) => {
      if (screen) {
        screen.classList.remove('active');
      }
    });

    const target = document.getElementById(`screen-${screenName}`);
    if (target) {
      target.classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  },

  showIdeaError(message) {
    this.elements.ideaError.textContent = message;
    this.elements.ideaError.hidden = false;
  },

  clearIdeaError() {
    this.elements.ideaError.textContent = '';
    this.elements.ideaError.hidden = true;
  },

  showQuestionError(message) {
    this.elements.questionError.textContent = message;
    this.elements.questionError.hidden = false;
  },

  clearQuestionError() {
    this.elements.questionError.textContent = '';
    this.elements.questionError.hidden = true;
  },

  updateAnalyzingProgress(percent, title, stepText) {
    if (this.elements.analyzingBar) this.elements.analyzingBar.style.width = `${percent}%`;
    if (title && this.elements.analyzingTitle) this.elements.analyzingTitle.textContent = title;
    if (stepText && this.elements.analyzingStep) this.elements.analyzingStep.textContent = stepText;
  },

  renderQuestion(question, currentIndex, totalQuestions, existingAnswer) {
    this.clearQuestionError();
    
    this.elements.questionMeta.textContent = `Question ${currentIndex + 1} of ${totalQuestions}`;
    this.elements.questionText.textContent = question.title;

    if (question.helpText) {
      this.elements.questionHelp.textContent = question.helpText;
      this.elements.questionHelp.hidden = false;
    } else {
      this.elements.questionHelp.hidden = true;
    }

    // Toggle Back button
    this.elements.btnQuestionBack.style.visibility = currentIndex > 0 ? 'visible' : 'hidden';

    // Clear previous inputs
    this.elements.answerControls.innerHTML = '';

    const currentVal = existingAnswer !== undefined ? existingAnswer : question.default;

    if (question.type === 'single_choice' || !question.type) {
      question.options.forEach((opt, idx) => {
        const isChecked = currentVal === opt;
        const label = document.createElement('label');
        label.className = `choice-tile ${isChecked ? 'selected' : ''}`;
        label.innerHTML = `
          <input type="radio" name="question_answer" value="${opt}" ${isChecked ? 'checked' : ''}>
          <span class="choice-text">${opt}</span>
        `;
        label.addEventListener('change', () => {
          document.querySelectorAll('.choice-tile').forEach((el) => el.classList.remove('selected'));
          label.classList.add('selected');
        });
        this.elements.answerControls.appendChild(label);
      });
    } else if (question.type === 'multiple_choice') {
      const selectedArr = Array.isArray(currentVal) ? currentVal : [];
      question.options.forEach((opt) => {
        const isChecked = selectedArr.includes(opt);
        const label = document.createElement('label');
        label.className = `choice-tile ${isChecked ? 'selected' : ''}`;
        label.innerHTML = `
          <input type="checkbox" name="question_answer" value="${opt}" ${isChecked ? 'checked' : ''}>
          <span class="choice-text">${opt}</span>
        `;
        label.addEventListener('change', (e) => {
          if (e.target.checked) {
            label.classList.add('selected');
          } else {
            label.classList.remove('selected');
          }
        });
        this.elements.answerControls.appendChild(label);
      });
    } else if (question.type === 'text' || question.type === 'number') {
      const input = document.createElement('input');
      input.type = question.type;
      input.name = 'question_answer';
      input.className = 'text-answer-input';
      input.value = currentVal || '';
      input.placeholder = question.placeholder || 'Type your answer here...';
      input.required = true;
      this.elements.answerControls.appendChild(input);
      setTimeout(() => input.focus(), 50);
    }
  },

  getAnswerFromDOM(questionType) {
    if (questionType === 'single_choice' || !questionType) {
      const selected = document.querySelector('input[name="question_answer"]:checked');
      return selected ? selected.value : null;
    } else if (questionType === 'multiple_choice') {
      const checked = document.querySelectorAll('input[name="question_answer"]:checked');
      return Array.from(checked).map((el) => el.value);
    } else {
      const input = document.querySelector('input[name="question_answer"]');
      return input ? input.value.trim() : '';
    }
  },

  renderReview(idea, requirements) {
    this.elements.reviewOriginalIdea.textContent = idea;
    this.elements.reviewAnswersList.innerHTML = '';

    for (const [key, value] of Object.entries(requirements)) {
      const card = document.createElement('div');
      card.className = 'review-item';
      card.innerHTML = `
        <span class="review-key">${key}</span>
        <div class="review-spec-value">${value}</div>
      `;
      this.elements.reviewAnswersList.appendChild(card);
    }
  },

  renderResult(promptText, taskType, qualityScore) {
    this.elements.promptOutput.textContent = promptText;
    this.elements.promptTag.textContent = taskType || 'General Task';
    this.elements.qualityScoreValue.textContent = `${qualityScore || 94}/100`;

    const words = promptText.trim().split(/\s+/).filter(Boolean).length;
    this.elements.promptWordCount.textContent = `${words} words`;

    // Reset copy button state
    this.elements.btnCopyPrompt.classList.remove('copied');
    this.elements.copyBtnLabel.textContent = 'Copy Prompt';
  },

  showCopySuccess() {
    this.elements.btnCopyPrompt.classList.add('copied');
    this.elements.copyBtnLabel.textContent = 'Copied ✓';
    setTimeout(() => {
      this.elements.btnCopyPrompt.classList.remove('copied');
      this.elements.copyBtnLabel.textContent = 'Copy Prompt';
    }, 2000);
  },

  renderError(title, message) {
    this.elements.errorTitle.textContent = title || 'Something went wrong';
    this.elements.errorMsg.textContent = message || 'We couldn\'t process your request. Please try again.';
    this.showScreen('error');
  }
};