/**
 * storage.js
 * Clean abstraction layer for LocalStorage persistence.
 */

const STORAGE_KEYS = {
  DRAFT_IDEA: 'pg_draft_idea',
  SESSION_DATA: 'pg_session_state',
  RECENT_PROMPTS: 'pg_recent_prompts'
};

const StorageService = {
  saveDraftIdea(text) {
    try {
      if (!text) {
        localStorage.removeItem(STORAGE_KEYS.DRAFT_IDEA);
      } else {
        localStorage.setItem(STORAGE_KEYS.DRAFT_IDEA, text);
      }
    } catch (e) {
      console.warn('LocalStorage unavailable:', e);
    }
  },

  getDraftIdea() {
    try {
      return localStorage.getItem(STORAGE_KEYS.DRAFT_IDEA) || '';
    } catch (e) {
      return '';
    }
  },

  saveSession(stateObj) {
    try {
      localStorage.setItem(STORAGE_KEYS.SESSION_DATA, JSON.stringify(stateObj));
    } catch (e) {
      console.warn('Could not persist session:', e);
    }
  },

  getSession() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SESSION_DATA);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  },

  clearSession() {
    try {
      localStorage.removeItem(STORAGE_KEYS.SESSION_DATA);
    } catch (e) {
      console.warn('Could not clear session storage:', e);
    }
  }
};