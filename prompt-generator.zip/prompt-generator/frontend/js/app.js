/**
 * app.js
 * Main application coordinator, event binding, and lifecycle engine.
 */

document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

function initApp() {
  bindEvents();
  restoreStateIfAvailable();
}

function bindEvents() {
  // Brand Click / Restart
  UI.elements.brandLogo.addEventListener('click', () => {
    resetToHome();
  });
  UI.elements.brandLogo.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      resetToHome();
    }
  });

  // Textarea input char count & draft save
  UI.elements.ideaInput.addEventListener('input', (e) => {
    const val = e.target.value;
    UI.elements.ideaCharCount.textContent = `${val.length} / 2000`;
    StorageService.saveDraftIdea(val);
    if (val.trim().length > 0) {
      UI.clearIdeaError();
    }
  });

  // Example Chips
  UI.elements.exampleChips.forEach((chip) => {
    chip.addEventListener('click', () => {
      const example = chip.getAttribute('data-example');
      UI.elements.ideaInput.value = example;
      UI.elements.ideaCharCount.textContent = `${example.length} / 2000`;
      StorageService.saveDraftIdea(example);
      UI.clearIdeaError();
      UI.elements.ideaInput.focus();
    });
  });

  // Step 1: Submit Idea
  UI.elements.ideaForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const idea = UI.elements.ideaInput.value.trim();

    if (!idea) {
      UI.showIdeaError('Tell us what you want to accomplish first.');
      UI.elements.ideaInput.focus();
      return;
    }

    AppState.originalIdea = idea;
    await processIdeaAnalysis();
  });

  // Step 2: Answer Questions
  UI.elements.questionForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const currentQ = AppState.getCurrentQuestion();
    if (!currentQ) return;

    const answer = UI.getAnswerFromDOM(currentQ.type);

    if (answer === null || answer === '' || (Array.isArray(answer) && answer.length === 0)) {
      UI.showQuestionError('Please provide or select an answer to continue.');
      return;
    }

    AppState.setAnswer(currentQ.id, answer);

    if (AppState.hasNextQuestion()) {
      AppState.currentQuestionIndex++;
      displayCurrentQuestion();
    } else {
      showReviewScreen();
    }
  });

  // Question Back Navigation
  UI.elements.btnQuestionBack.addEventListener('click', () => {
    if (AppState.hasPreviousQuestion()) {
      AppState.currentQuestionIndex--;
      displayCurrentQuestion();
    }
  });

  // Review Confirm & Generate
  UI.elements.btnReviewConfirm.addEventListener('click', async () => {
    await processPromptGeneration();
  });

  // Review Edit Answers
  UI.elements.btnReviewBack.addEventListener('click', () => {
    AppState.currentQuestionIndex = AppState.questions.length - 1;
    displayCurrentQuestion();
  });

  // Result Actions: Copy to clipboard
  UI.elements.btnCopyPrompt.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(AppState.generatedPrompt);
      UI.showCopySuccess();
    } catch (err) {
      // Fallback copy execution
      const pre = UI.elements.promptOutput;
      const range = document.createRange();
      range.selectNodeContents(pre);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      document.execCommand('copy');
      UI.showCopySuccess();
    }
  });

  // Result Actions: Edit
  UI.elements.btnResultEdit.addEventListener('click', () => {
    showReviewScreen();
  });

  // Result Actions: Regenerate
  UI.elements.btnResultRegenerate.addEventListener('click', async () => {
    await processPromptGeneration();
  });

  // Result Actions: Restart
  UI.elements.btnResultRestart.addEventListener('click', () => {
    resetToHome();
  });

  // Error Actions
  UI.elements.btnErrorRetry.addEventListener('click', () => {
    if (AppState.originalIdea) {
      processIdeaAnalysis();
    } else {
      resetToHome();
    }
  });
  UI.elements.btnErrorHome.addEventListener('click', () => {
    resetToHome();
  });
}

function restoreStateIfAvailable() {
  const draft = StorageService.getDraftIdea();
  if (draft) {
    UI.elements.ideaInput.value = draft;
    UI.elements.ideaCharCount.textContent = `${draft.length} / 2000`;
  }
}

async function processIdeaAnalysis() {
  UI.showScreen('analyzing');
  UI.updateAnalyzingProgress(30, 'Understanding your idea...', 'Analyzing what you need and identifying key parameters');

  try {
    const analysis = await ApiClient.analyzeIdea(AppState.originalIdea);
    UI.updateAnalyzingProgress(85, 'Preparing questions...', 'Tailoring dynamic clarifying questions');

    AppState.taskType = analysis.taskType;
    AppState.questions = analysis.questions;
    AppState.currentQuestionIndex = 0;
    AppState.answers = {};

    setTimeout(() => {
      displayCurrentQuestion();
    }, 400);
  } catch (error) {
    UI.renderError('Analysis Failed', 'We could not process your request at this time. Please try again.');
  }
}

function displayCurrentQuestion() {
  const currentQ = AppState.getCurrentQuestion();
  if (!currentQ) return;

  const existingAnswer = AppState.getAnswer(currentQ.id);
  UI.renderQuestion(currentQ, AppState.currentQuestionIndex, AppState.questions.length, existingAnswer);
  UI.showScreen('question');
}

async function showReviewScreen() {
  try {
    const requirements = await ApiClient.buildRequirements(
      AppState.originalIdea,
      AppState.taskType,
      AppState.questions,
      AppState.answers
    );
    AppState.requirements = requirements;
    UI.renderReview(AppState.originalIdea, requirements);
    UI.showScreen('review');
  } catch (error) {
    UI.renderError('Review Error', 'Failed to compile requirements summary.');
  }
}

async function processPromptGeneration() {
  UI.showScreen('analyzing');
  UI.updateAnalyzingProgress(40, 'Crafting your prompt...', 'Applying prompt-engineering principles and contextual constraints');

  try {
    const prompt = await ApiClient.generatePrompt(
      AppState.originalIdea,
      AppState.taskType,
      AppState.requirements
    );
    UI.updateAnalyzingProgress(100, 'Finalizing...', 'Ready');

    AppState.generatedPrompt = prompt;

    setTimeout(() => {
      UI.renderResult(AppState.generatedPrompt, AppState.taskType, AppState.qualityScore);
      UI.showScreen('result');
    }, 400);
  } catch (error) {
    UI.renderError('Generation Failed', 'Could not assemble your final prompt.');
  }
}

function resetToHome() {
  AppState.reset();
  UI.elements.ideaInput.value = '';
  UI.elements.ideaCharCount.textContent = '0 / 2000';
  UI.clearIdeaError();
  StorageService.saveDraftIdea('');
  UI.showScreen('home');
}

/**
 * app.js
 * Frontend controller orchestrating live API interactions with the backend.
 */

document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

function initApp() {
  bindEvents();
  restoreDraft();
}

function bindEvents() {
  // Brand Click / Restart
  UI.elements.brandLogo.addEventListener('click', resetToHome);
  UI.elements.brandLogo.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      resetToHome();
    }
  });

  // Textarea input char count & draft save
  UI.elements.ideaInput.addEventListener('input', (e) => {
    const val = e.target.value;
    UI.elements.ideaCharCount.textContent = `${val.length} / 2000`;
    StorageService.saveDraftIdea(val);
    if (val.trim().length > 0) {
      UI.clearIdeaError();
    }
  });

  // Example Chips
  UI.elements.exampleChips.forEach((chip) => {
    chip.addEventListener('click', () => {
      const example = chip.getAttribute('data-example');
      UI.elements.ideaInput.value = example;
      UI.elements.ideaCharCount.textContent = `${example.length} / 2000`;
      StorageService.saveDraftIdea(example);
      UI.clearIdeaError();
      UI.elements.ideaInput.focus();
    });
  });

  // 1. Submit Idea -> Start Session
  UI.elements.ideaForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const idea = UI.elements.ideaInput.value.trim();

    if (!idea) {
      UI.showIdeaError('Tell us what you want to accomplish first.');
      UI.elements.ideaInput.focus();
      return;
    }

    AppState.originalIdea = idea;
    await startPromptSession();
  });

  // 2. Submit Question Answer
  UI.elements.questionForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const currentQ = AppState.getCurrentQuestion();
    if (!currentQ) return;

    const answer = UI.getAnswerFromDOM(currentQ.type);
    if (answer === null || answer === '' || (Array.isArray(answer) && answer.length === 0)) {
      UI.showQuestionError('Please provide or select an answer to continue.');
      return;
    }

    await submitCurrentAnswer(currentQ.id, answer);
  });

  // Question Back Navigation
  UI.elements.btnQuestionBack.addEventListener('click', () => {
    if (AppState.hasPreviousQuestion()) {
      AppState.currentQuestionIndex--;
      const prevQ = AppState.getCurrentQuestion();
      const prevAns = AppState.getAnswer(prevQ.id);
      UI.renderQuestion(prevQ, AppState.currentQuestionIndex, AppState.questions.length, prevAns);
      UI.showScreen('question');
    }
  });

  // Review Confirm & Generate
  UI.elements.btnReviewConfirm.addEventListener('click', async () => {
    await processPromptGeneration();
  });

  // Review Edit Answers
  UI.elements.btnReviewBack.addEventListener('click', () => {
    AppState.currentQuestionIndex = AppState.questions.length - 1;
    const currentQ = AppState.getCurrentQuestion();
    const currentAns = AppState.getAnswer(currentQ.id);
    UI.renderQuestion(currentQ, AppState.currentQuestionIndex, AppState.questions.length, currentAns);
    UI.showScreen('question');
  });

  // Result: Copy to Clipboard
  UI.elements.btnCopyPrompt.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(AppState.generatedPrompt);
      UI.showCopySuccess();
    } catch (err) {
      const pre = UI.elements.promptOutput;
      const range = document.createRange();
      range.selectNodeContents(pre);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      document.execCommand('copy');
      UI.showCopySuccess();
    }
  });

  // Result: Edit
  UI.elements.btnResultEdit.addEventListener('click', () => {
    UI.renderReview(AppState.originalIdea, AppState.requirements);
    UI.showScreen('review');
  });

  // Result: Regenerate
  UI.elements.btnResultRegenerate.addEventListener('click', async () => {
    await processPromptGeneration();
  });

  // Result: Restart
  UI.elements.btnResultRestart.addEventListener('click', resetToHome);

  // Error Actions
  UI.elements.btnErrorRetry.addEventListener('click', () => {
    if (AppState.originalIdea) {
      startPromptSession();
    } else {
      resetToHome();
    }
  });
  UI.elements.btnErrorHome.addEventListener('click', resetToHome);
}

function restoreDraft() {
  const draft = StorageService.getDraftIdea();
  if (draft) {
    UI.elements.ideaInput.value = draft;
    UI.elements.ideaCharCount.textContent = `${draft.length} / 2000`;
  }
}

async function startPromptSession() {
  UI.showScreen('analyzing');
  UI.updateAnalyzingProgress(30, 'Analyzing your idea...', 'Categorizing task and identifying missing parameters');

  try {
    const data = await ApiClient.startSession(AppState.originalIdea);
    AppState.sessionId = data.sessionId;
    AppState.taskType = data.taskType;

    if (data.status === 'ready') {
      AppState.requirements = data.summary || { Goal: AppState.originalIdea };
      UI.updateAnalyzingProgress(100, 'Ready', 'Done');
      UI.renderReview(AppState.originalIdea, AppState.requirements);
      UI.showScreen('review');
      return;
    }

    if (data.status === 'question' && data.question) {
      AppState.questions = [data.question];
      AppState.currentQuestionIndex = 0;
      UI.updateAnalyzingProgress(100, 'Ready', 'Done');
      UI.renderQuestion(data.question, 0, 1, undefined);
      UI.showScreen('question');
    }
  } catch (error) {
    UI.renderError('Analysis Failed', error.message || 'We could not analyze your request.');
  }
}

async function submitCurrentAnswer(questionId, answer) {
  AppState.setAnswer(questionId, answer);
  UI.showScreen('analyzing');
  UI.updateAnalyzingProgress(50, 'Evaluating requirements...', 'Checking if more details are needed');

  try {
    const data = await ApiClient.submitAnswer(AppState.sessionId, questionId, answer);

    if (data.status === 'question' && data.question) {
      // Append newly identified question dynamically
      AppState.questions.push(data.question);
      AppState.currentQuestionIndex = AppState.questions.length - 1;
      UI.renderQuestion(data.question, AppState.currentQuestionIndex, AppState.questions.length, undefined);
      UI.showScreen('question');
    } else {
      // Requirements complete -> Transition to Review
      AppState.requirements = data.summary || AppState.answers;
      UI.renderReview(AppState.originalIdea, AppState.requirements);
      UI.showScreen('review');
    }
  } catch (error) {
    UI.renderError('Submission Failed', error.message || 'Could not process your answer.');
  }
}

async function processPromptGeneration() {
  UI.showScreen('analyzing');
  UI.updateAnalyzingProgress(60, 'Assembling your prompt...', 'Applying domain constraints and formatting output');

  try {
    const data = await ApiClient.generatePrompt(AppState.sessionId);
    AppState.generatedPrompt = data.prompt;
    AppState.qualityScore = data.qualityScore || 94;

    UI.renderResult(AppState.generatedPrompt, AppState.taskType, AppState.qualityScore);
    UI.showScreen('result');
  } catch (error) {
    UI.renderError('Generation Failed', error.message || 'Could not generate your prompt.');
  }
}

function resetToHome() {
  AppState.reset();
  UI.elements.ideaInput.value = '';
  UI.elements.ideaCharCount.textContent = '0 / 2000';
  UI.clearIdeaError();
  StorageService.saveDraftIdea('');
  UI.showScreen('home');
}