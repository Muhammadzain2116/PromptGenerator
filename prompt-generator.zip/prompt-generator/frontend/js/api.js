/**
 * api.js
 * Connected production client communicating with the backend Express REST API.
 */

const API_BASE = '/api/prompt';

const ApiClient = {
  /**
   * Start session and analyze user idea.
   * @param {string} idea
   * @returns {Promise<Object>}
   */
  async startSession(idea) {
    const response = await fetch(`${API_BASE}/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ idea })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error?.message || 'Failed to analyze idea.');
    }
    return data;
  },

  /**
   * Submit an answer to the current question.
   * @param {string} sessionId
   * @param {string} questionId
   * @param {any} answer
   * @returns {Promise<Object>}
   */
  async submitAnswer(sessionId, questionId, answer) {
    const response = await fetch(`${API_BASE}/answer`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId, questionId, answer })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error?.message || 'Failed to submit answer.');
    }
    return data;
  },

  /**
   * Generate final prompt.
   * @param {string} sessionId
   * @returns {Promise<Object>}
   */
  async generatePrompt(sessionId) {
    const response = await fetch(`${API_BASE}/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error?.message || 'Failed to generate final prompt.');
    }
    return data;
  }
};