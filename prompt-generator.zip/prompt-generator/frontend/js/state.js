/**
 * state.js
 * Centralized immutable-friendly application state management.
 */

const AppState = {
  currentScreen: 'home', // 'home' | 'analyzing' | 'question' | 'review' | 'result' | 'error'
  originalIdea: '',
  taskType: 'general',
  questions: [],
  currentQuestionIndex: 0,
  answers: {}, // { [questionId]: value }
  requirements: {}, // Extracted structured summary
  generatedPrompt: '',
  qualityScore: 94,
  errorMessage: '',

  /**
   * Reset the entire session state to clean initial defaults
   */
  reset() {
    this.currentScreen = 'home';
    this.originalIdea = '';
    this.taskType = 'general';
    this.questions = [];
    this.currentQuestionIndex = 0;
    this.answers = {};
    this.requirements = {};
    this.generatedPrompt = '';
    this.qualityScore = 94;
    this.errorMessage = '';
    StorageService.clearSession();
  },

  getCurrentQuestion() {
    return this.questions[this.currentQuestionIndex] || null;
  },

  setAnswer(questionId, value) {
    this.answers[questionId] = value;
  },

  getAnswer(questionId) {
    return this.answers[questionId];
  },

  hasNextQuestion() {
    return this.currentQuestionIndex < this.questions.length - 1;
  },

  hasPreviousQuestion() {
    return this.currentQuestionIndex > 0;
  }
};